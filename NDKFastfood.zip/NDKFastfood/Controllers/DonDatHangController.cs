﻿using NDKFastfood.Models;
using System.Linq;
using System.Web.Mvc;

namespace NDKFastfood.Controllers
{
    public class DonDatHangController : Controller
    {
        dbKiwiFastfoodDataContext data = new dbKiwiFastfoodDataContext();
        public ActionResult Index()
        {
            if (Session["TaiKhoan"] == null)
            {
                return RedirectToAction("DangNhap", "NguoiDung");
            }
            var khachHang = (KhachHang)Session["TaiKhoan"];
            var khachHangId = khachHang.MaKH;
            var chuaGiao = data.DonDatHangs
                .Where(dh => dh.MaKH == khachHangId && dh.TinhTrangGiaohang == false)
                .ToList();

            var daGiao = data.DonDatHangs
                .Where(dh => dh.MaKH == khachHangId && dh.TinhTrangGiaohang == true)
                .ToList();

            ViewBag.DaGiao = daGiao;
            ViewBag.ChuaGiao = chuaGiao;

            return View();
        }
    }
}